#!/usr/bin/python
from pygine.root import Game
game = Game()
game.run()
