debug = False
money = 0
on_cpi = False