debug = False
money = 0